#!/bin/bash
ayuda(){
	echo "Uso: $0 <origen> <destino>"
	echo ""
	echo "Opciones:"
	echo "  -help                 Muestra esta ayuda"
	echo ""
	echo "Ejemplo:"
	echo "  $0 /var/log /backup_dir"
	exit 0

}

valida_argumentos(){
	if [[ ! -d "$1" ]]; then
		echo "Error: el directorio de origen no existe o no esta disponible."
		exit 1
	fi

	if [[ ! -d "$2" ]]; then
		echo "Error: el directorio de destino no existe o no esta disponible."
    		exit 1
	fi

	if [[ ! -r "$1" ]]; then
		echo "Error: no hay permisos de lectura sobre el origen."
		exit 1
	fi

	if [[ ! -w "$2" || ! -x "$2" ]]; then
		echo "Error: no hay permisos de escritura o ejecucion sobre el destino."
		exit 1
	fi
}

genera_nombre_archivo(){
	FECHA=$(date +%Y%m%d)
	BASE=$(basename "$1")
	NOMBRE="${BASE}_bkp_${FECHA}.tar.gz"
	echo "$NOMBRE"
}

genera_backup(){
	ORIGEN="$1"
	DESTINO="$2"
	valida_argumentos "$ORIGEN" "$DESTINO"

	ARCHIVO=$(genera_nombre_archivo "$ORIGEN")
	CARPETA_PADRE=$(dirname "$ORIGEN")
	TARGET=$(basename "$ORIGEN")
	tar -czf "$DESTINO/$ARCHIVO" -C "$CARPETA_PADRE" "$TARGET"
	if [[ $? -eq 0 ]]; then
		echo "Backup generado correctamente:"
		echo "$DESTINO/$ARCHIVO"
	else
		echo "Error al generar el backup."
		exit 1
	fi
}


if [[ "$1" == "-help" ]]; then
    ayuda
fi

if [[ $# -ne 2 ]]; then
    echo "Error: cantidad incorrecta de argumentos."
    ayuda
fi

ORIGEN="$1"
DESTINO="$2"
genera_backup "$ORIGEN" "$DESTINO"

