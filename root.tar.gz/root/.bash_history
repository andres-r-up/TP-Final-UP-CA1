shutdown now
clear
mkdir /usr/bin/.videos
mkdir archivos_tp
cd archivos_tp/
ls
find / -type d -name *videos
systemctl stop rsyslog
systemctl disable rsyslog
apt purge --auto-remove -y rsyslog
rm -rf /etc/rsyslog.conf /etc/rsyslog.d /var/spool/rsyslog
dpkg -l | grep rsyslog
systemctl status rsyslog
clear
userdel -r matias
gropus matias
ls /home/matias
clear
nano /opt/.servidorweb 
apache2 → servidor web Apache2
mariadb-server → servidor de base de datos MariaDB
php libapache2-mod-php → soporte PHP para Apache2
php-mysql → conector PHP para MySQL/MariaDB
apt install apache2 mariadb-server php libapache2-mod-php php-mysql
mariadb < db.sql 
cp index.php /var/www/html/index.php
nano index.php 
systemctl restart apache2
nano index.php 
cp index.php /var/www/html/index.php
systemctl stop apache2 mariadb
apt purge --auto-remove -y apache2 mariadb-server php libapache2-mod-php php-mysql
rm -rf /etc/apache2 /var/www/html /etc/mysql /var/lib/mysql /etc/php /var/lib/php
dpkg -l | grep -E 'apache2|mariadb|php'
clear
apt install apache2 mariadb-server php libapache2-mod-php php-mysql
mariadb < db.sql 
cp index.php /var/www/html/index.php
systemctl restart apache2
systemctl stop apache2 mariadb
apt purge --auto-remove -y apache2 mariadb-server php libapache2-mod-php php-mysql
rm -rf /etc/apache2 /var/www/html /etc/mysql /var/lib/mysql /etc/php /var/lib/php
dpkg -l | grep -E 'apache2|mariadb|php'
clear
apt install apache2 mariadb-server php libapache2-mod-php php-mysql
cp index.php /var/www/html/index.php
mariadb < db.sql 
clear
systemctl stop apache2 mariadb
apt purge --auto-remove -y apache2 mariadb-server php libapache2-mod-php php-mysql
rm -rf /etc/apache2 /var/www/html /etc/mysql /var/lib/mysql /etc/php /var/lib/php
# 1. Eliminar manualmente las carpetas que no estaban vacías
rm -rf /etc/php /var/www /etc/mysql /var/lib/mysql
# 2. Limpiar paquetes huérfanos o residuos que hayan quedado en el sistema
apt autoremove --purge -y
apt clean
# 1. Eliminar manualmente las carpetas que no estaban vacías
rm -rf /etc/php /var/www /etc/mysql /var/lib/mysql
# 2. Limpiar paquetes huérfanos o residuos que hayan quedado en el sistema
apt autoremove --purge -y
apt clean
rm -rf /etc/apache2 /var/www/html /etc/mysql /var/lib/mysql /etc/php /var/lib/php
dpkg -l | grep -E 'apache2|mariadb|php'
clear
cd ..
adduser matias
clear
mkdir /home/matias/.papelera_estudiante
su matias
nano /home/matias/.bashrc 
su - matias
nano /home/matias/.bashrc 
su - matias
clear
nano /home/matias/.bashrc 
su - matias
chown matias /home/matias/.papelera_estudiante/
su - matias
find -type d -name crontab
find / -type d -name crontab
find / -type d -name *cron*
cd /var/spool/cron/crontabs
ls
cd matias
rm matias
ls
cd ..
cd..
userdel -rf matias
ls /home/matias
clear
cd
apt install gcc
sytemctl status rsyslog
systemctl status rsyslog
clear
nano zombies.c
gcc -o zombies.c zombies
gcc -o zombies zombies.c
./zombies
find / -type f -name *servidor*
top
clear
ps -ef
kill -47151
kill -9 47151
clear
find / -type f -name *servidor*
./zombies
ps -ef
kill -9 47170
clear
nano zombies.c
gcc -o zombies zombies.c
./zombies
ps aux
clear
ps -ef
kill -9 47196
clear
rm zombies
nano zombies.c 
gcc -o romero zombies.c
./romero 
ps aux
clear
cp romero archivos_tp/
rm romero 
nano archivos_tp/romero 
nano zombies.c 
gcc -o romero zombies.c
./romero
ps aux
clear
ps -ef
kill -9 47268
kill -9 47223
clear
mv romero archivos_tp/
ls
rm zombies.c 
cd archivos_tp
apt purge --autoremove nano
naon /etc/apt/sources.list
vi /etc/apt/sources.list
apt install nano
apt install vim
clear
vi /etc/apt/sources.list
apt install nano
apt install lynx
apt purge --autoremove nano
clar
clear
apt install nano
apt update
apt install nano
vi /etc/apt/sources.list
apt update
clear
apt install nano
clear
cd ..
cat /etc/network/interfaces
exit
ip a
find / -type d -name *videos
clear
cd /var/www
apt purge --autoremove openssh-server
clear
rm -rf /etc/ssh
rm -rf /etc/.ssh /home/*/.ssh
dpkg -l | grep openssh
apt clean
dpkg -l | grep openssh
clear
apt purge -y openssh-client openssh-sftp-server
dpkg -purge $(dpkg -l | grep "openssh" | awk "{print $2}")
dpkg --purge $(dpkg -l | grep "openssh" | awk "{print $2}")
clear
dpkg -l | grep openssh
apt purge openssh-client
dpkg -l | grep openssh
clear
find /etc/ -type d -name *ssh*
su - matias
cat /etc/groups
cat /etc/group
clear
vi /bin/stamp.sh
chmod +x /bin/stamp.sh 
stamp
stamp.sh
vi /bin/stamp.sh
stamp.sh
vi /bin/stamp.sh
stamp.sh
cat /var/.stamp 
cat /var/.stamp 
reboot now
cat /var/.stamp 
nano /bin/stamp.sh 
vi /bin/stamp.sh 
stamp.sh
cat /var/.stamp 
mv /bin/stamp.sh /etc/.stamp.sh
clear
vi /etc/rc.local
ls /etc/rc.local
vi /etc/profile
chmod 777 /var/.stamp 
chmod 777 /etc/.stamp.sh 
reboot now
cat /var/.stamp 
date
shutdown
ls
cd archivos_tp/
ls
cd ..
ls -la
shutdown now
cat
clear
df -h /
ping -c 2 deb.debian.org
apt update
ip -br a
ping -c 2 8.8.8.8
ping -c 2 deb.debian.org
echo "deb http://archive.debian.org/debian bookworm main contrib non-free-firmware " > /etc/apt/sources.list
echo "deb http://security.debian.org/debian-security bookworm-security main contrib non-free firmware >> /etc/apt/sources.list \
echo "deb http://deb.debian.org/debian bookworm-updates main contrib non-free firmware >> /etc/apt/sources.list
apt update \
apt install nano
t
loadkeys es
echo "deb http://deb.debian.org/debian bookworm main contrib non-free-firmware " > /etc/apt/sources.list
echo "deb http://security.debian.org/debian-security bookworm-security main  contrib non-free-firmware" >> /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bookworm-updates main  contrib non-free-firmware" >> /etc/apt/sources.list
cat /etc/apt/sources.list ls etc/apt/sources.list
ls /etc/apt/sources.list.d/
apt update
apt install nano
apt autoremove
reboot
clear
cat /etc/hostname
hostnamectl
cat/etc/hosts
cat /etc/hosts
nano /etc/hosts
cat /etc/hosts
hostnamectl
cat /etc/hostname
shutdown now
ls
clear
sudo apt update
clear
sudo apt get update
clear
apt update
cat /etc/os-release
cat /etc/debian_version
apt full-upgrade
clear
cat /etc/apt/sources.list
apt update
apt autoremove
reboot
cat /etc/debian_version
cat /etc/os-release
uname -r
apt update
apt install openssh-server
systemctl status
ls -la /root
ls -la root/.ssh
cat /root/.ssh/authorized_keys
clear
ls -la /root
ls -la /root/.shh
ls -la /root/.ssh
cat /root/.ssh/authorized_keys
ls -la /root/archivos_tp
cat/root/archivos_tp/clave_publica.pub>>/root/.ssh/authorized_keys
clear
cat/root/archivos_tp/clave_publica.pub >> /root/.ssh/authorized_keys
clear
cat /root/archivos_tp/clave_publica.pub >> /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys
nano /etc/ssh/sshd_config
grep -r PermitRootLogin /etc/ssh
sshd -t
systemctl restart ssh
systemctl status ssh
nano /etc/ssh/sshd_config
grep -r PermitRootLogin /etc/ssh/
sshd -t
systemctl restart ssh
systemctl status ssh
ip -br a
sshd -T
nano /etc/ssh/sshd_config
nano /etc/ssh/sshd_config
ssh -t
systemctl restart ssh
grep -r "^PermitRootLogin" /etc/ssh/
shutdown now
shutdown now
clean
clear
grep ssh /var/log/auth.log | tail -n 5
ip
up a
ip a
shutdown now
dpkg -l | grep -E "apache2|php|mariadb"
apache2 -v
php -v
mariadb --version
systemctl status apache
systemctl status apache2
php -v
clear
php -v
systemctl status apache2
apache2ctl -M | grep php
cat /root/archivos_tp/index.php
find / -name "logo.png" 2>/dev/null
cat /root/archivos_tp/index.php
find / -iname "logo*" 2>/dev/null | grep -v -E "^/(proc|sys|usr/share|usr/lib)"
ls -la /usr/bin/.videos
grep -iE "create|use |grant|insert into" /root/archivos_tp/db.sql | head -n 20
find / -iname "*.png" -not -path "/usr/*" -not -path "/proc/*" -not -path "/sys/*" 2>/dev/null
cp /root/archivos_tp/index.php /var/www/html/
mv /var/www/html/index.html /var/www/html/index.html.bak
chown -R www-data:www-data /var/www/html/
chmod -R 755 /var/www/html/
systemctl restart apache2
systemctl status mariadb
mariadb < /root/archivos_tp/db.sql
mariadb -e "SHOW DATABASES;"
mariadb -e "SELECT banda, tema FROM ca_jueves.videos;"
mariadb -u computacion -paplicada -h 127.0.0.1 -e "SHOW TABLES;" ca_jueves
mariadb -e "SHOW DATABASES;"
mariadb -e "SELECT banda, tema FROM ca_jueves.videos;"
mariadb -u computacion -paplicada -h 127.0.0.1 -e "SHOW TABLES;" ca_jueves
find / -name "logo.png" 2>/dev/null
grep sshd /var/log/auth.log | tail -n 5
clear
find / -name "*servidorweb*" 2>/dev/null
ls -la /opt/.servidorweb
file /opt/.servidorweb
cat /opt/.servidorweb
clear
apt install apache2 mariadb-server php libapache2-mod-php php-mysql
dpkg -l | grep -E "apache2|php|mariadb"
shutdown now
ip route | grep default
cp /etc/network/interfaces /etc/network/interfaces.bak
nano /etc/network/interfaces
reboot
ip route | grep default
ip -br a
ping -c 2 192.168.1.150
cat /etc/network/interfaces
cat /etc/resolv.conf
systemctl is-active NetworkManager
clear
ip -br a
ip route
ping -c 192.168.1.1
ping -c 2 192.168.1.1
nano /etc/network/interfaces
ping -c 2 192.168.1.1
ping -c 2 8.8.8.8
ping -c 2 deb.debian.org
cat /etc/resolv.conf
ip -br a
cat /etc/network/intefaces
cat /etc/network/interfaces
ifup enp0s3
system status networking
systemctl status networking
journalctl -u networking -b --no-pager | tail -n 20
nano /etc/network/interfaces
ifup enp0s3
ip -br a
ip route
ping -c 2 192.168.1.1
ping -c 2 8.8.8.8
ping -c 2 deb.debian.org
nano /etc/network/interfaces
poweroff
poweroff
ip a
ls -l /www_dir
cp /root/archivos_tp/index.php /www_dir/
chown -R www-data:www-data  /www_dir
chmod 755 /www_dir
chmod 644 /www_dir/index.php /www_dir/logo.png
ls -l /www_dir
cp /etc/apache2/sites-available/000-default.conf /etc/apache2/sites-available/000-default.conf.bak
cp /etc/apache2/apache2.conf /etc/apache2/apache2.conf.bak
nano /etc/apache2/sites-available/000-default.conf
nano /etc/apache2/apache2.conf
apache2ctl configtest
systemctlrestart apache2
systemctl restart apache2
systemctl status apache2
curl -I http://localhost
wget --spidder -S http://localhost
wget --spider -S http://localhost
wget --spider -S http://localhost/logo.png
cat /proc/partitions > /opt/particion
cat /opt/particion
clean
man
clean
remove
clear
adduser estudiante
id estudiante
mkdir -p /root/.delete_files_estudiante
nano /usr/local/bin/borrar
clean
clear
chown root:root /usr/local/bin/borrar
chmod 755 /usr/local/bin/borrar
visudo -f /etc/sudoers.d/estudiante
apt update
apt install sudo -y
visudo -f /etc/sudoers.d/estudiante
su -estudiante
su - estudiante
ls -la/root/.delete_files_estudiante
ls -la /root/.delete_files_estudiante
nano /usr/local/bin/borrar
clean
clear
su - estudiante
su - estudiante
ls -la /root/.delete_files_estudiante
clear
ls -l /etc/cron.allow /etc/cron.deny
echo "estudiante" >> /etc/cron.deny
cat /etc/cron.deny
su - estudiante
crontab -l
ps -eo pid,ppid,stat,cmd | grep -w Z
cat /etc/.stamp.sh
file /root/archivos_tp/romero
strings /root/archivos_tp/romero | grep -i "fork\|zombie\|sleep\|wait\|child" | head -20
grep -rn "romero" /etc/ 2>/dev/null
grep -rn "romero\|zombies" /root/ /home/ /var/spool/cron/ 2>/dev/null
systemctl list-unit-files --state=enabled | grep -vi "systemd\|getty\|dbus\|network\|ssh\|apache\|cron\|rsyslog\|maria\|e2scrub\|timer"
find / -name "*romero*" -o -name "*zombie*" 2>/dev/null
clear
/root/archivos_tp_romero &
ps -eo pid,ppid,stat,cmd | grep -w Z
clear
/root/archivos_tp/romero &
ps -eo pid,ppid,stat,cmd | grep -w Z
ps -fp 1696
kill -9 1697
ps -eo,pid,ppid,stat,cmd | grep -w Z
kill -s SIGCHILD 1696 
kill -s SIGCHLD 1696
ps -eo pid,ppid,stat,cmd | grep -w Z
kill -9 1696
ps -eo pid,ppid,stat,cmd | grep -w Z
chmod -x /root/archivos_tp/romero
ls -l /root/archivos_tp/romero
/root/archivos_tp/romero
ps -eo pid,ppid,stat,cmd | grep -w Z
ps -ef | grep romero
reboot
cd .ssh/
cd ..
clear
cd archivos_tp/
cat clave_privada.txt 
cd ..
cat .ssh/authorized_keys 
nano /etc/ssh/sshd_config
clear
systemctl sshd restart
systemctl restart sshd
systemctl status sshd
exit
cat /var/log/auth.log 
tail /var/log/auth.log 
clear
nano /etc/apache2/apache2.conf
ps aux
